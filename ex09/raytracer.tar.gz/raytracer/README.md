## About
A raytracer in C. It has shadows, reflections, lightning ([phong model](http://en.wikipedia.org/wiki/Phong_reflection_model)).

## Usage
You could use a makefile located in raytracer directory (use apt-get or brew or whatever to get libpng).
It has 3 hardcoded demos, you can edit scene.c to change them.

For instance:
```
./raytracer teapot
```  

Have fun.

## License
[The MIT License (MIT)](http://opensource.org/licenses/mit-license.php)
