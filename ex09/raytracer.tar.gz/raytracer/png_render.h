//
//  png_main.h
//  raytracer
//
//  Created by Krzysztof Gabis on 13.04.2013.
//  Copyright (c) 2013 Krzysztof Gabis. All rights reserved.
//

#ifndef raytracer_png_main_h
#define raytracer_png_main_h

#include "raytracer.h"

void png_render(Raytracer *rt);

#endif
